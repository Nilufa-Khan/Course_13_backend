package com.example.demopc1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demopc1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demopc1Application.class, args);
	}

}
