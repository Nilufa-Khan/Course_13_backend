package com.example.demoMc1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMc1Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoMc1Application.class, args);
	}

}
