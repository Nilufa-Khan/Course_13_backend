package com.example.demoMc1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMc1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
